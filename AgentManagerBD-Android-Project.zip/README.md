# Agent Manager BD — Android source project

Personal, offline bookkeeping starter app for an individual mobile-banking agent.

## Included
- Fingerprint/device credential authentication using AndroidX BiometricPrompt.
- Local SQLite storage for transactions, opening balances and customer dues.
- Separate bKash, Nagad and Rocket ledgers.
- Cash-in / cash-out entry and manually entered commission.
- Daily/monthly summaries and PDF export/share sheet.

## Build
1. Install Android Studio (latest stable) and Android SDK 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Connect an Android phone with biometric enrollment, or use an emulator with biometric support.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

APK output is normally under `app/build/outputs/apk/debug/`.

## Important limitations
- This is a bookkeeping tool only. It does not connect to bKash/Nagad/Rocket, initiate payments, or verify real balances.
- Commission is entered manually. Commission is not the same as net profit; shop expenses are not yet recorded.
- PDF uses a basic text report. Printing is offered through Android's share/print-compatible apps.
- Data is stored locally on this phone. Uninstalling the app or clearing app data may erase it. Export/backup should be added before relying on it for business records.
- Fingerprint authentication requires compatible device biometrics; device credential is allowed as Android's supported fallback.
- Test with sample data before using for actual business records.
