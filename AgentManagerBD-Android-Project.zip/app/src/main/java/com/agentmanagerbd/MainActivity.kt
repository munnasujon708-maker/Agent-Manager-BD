package com.agentmanagerbd

import android.os.Bundle
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.pdf.PdfDocument
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.widget.*
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Tx(val id: Long, val service: String, val type: String, val amount: Long,
              val commission: Long, val customer: String, val date: String)

class DBHelper(c: android.content.Context): SQLiteOpenHelper(c, "agent_manager.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, service TEXT, type TEXT,
            amount INTEGER, commission INTEGER, customer TEXT, date TEXT)""")
        db.execSQL("""CREATE TABLE due(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,
            amount INTEGER, kind TEXT, date TEXT)""")
        db.execSQL("""CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT)""")
        listOf("cash","bkash","nagad","rocket").forEach {
            val cv=ContentValues(); cv.put("k",it); cv.put("v","0"); db.insert("settings",null,cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun setting(k:String):Long {
        val c=readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(k))
        val v=if(c.moveToFirst()) c.getString(0).toLongOrNull()?:0 else 0L; c.close(); return v
    }
    fun set(k:String,v:String) { val cv=ContentValues();cv.put("k",k);cv.put("v",v);writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE) }
    fun addTx(s:String,t:String,a:Long,com:Long,n:String,d:String) {
        val cv=ContentValues();cv.put("service",s);cv.put("type",t);cv.put("amount",a);cv.put("commission",com);cv.put("customer",n);cv.put("date",d)
        writableDatabase.insert("tx",null,cv)
    }
    fun txs():List<Tx> {
        val out=mutableListOf<Tx>(); val c=readableDatabase.rawQuery("SELECT id,service,type,amount,commission,customer,date FROM tx ORDER BY id DESC",null)
        while(c.moveToNext()) out.add(Tx(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getLong(4),c.getString(5),c.getString(6)))
        c.close();return out
    }
    fun addDue(n:String,a:Long,k:String,d:String) {
        val cv=ContentValues();cv.put("name",n);cv.put("amount",a);cv.put("kind",k);cv.put("date",d);writableDatabase.insert("due",null,cv)
    }
    fun dueTotal():Long {
        val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN kind='বাকি দেওয়া' THEN amount ELSE -amount END),0) FROM due",null)
        val v=if(c.moveToFirst()) c.getLong(0) else 0L;c.close();return v
    }
    fun dueRows():List<String> {
        val a=mutableListOf<String>();val c=readableDatabase.rawQuery("SELECT name,amount,kind,date FROM due ORDER BY id DESC",null)
        while(c.moveToNext()) a.add("${c.getString(0)} • ${c.getString(2)} • ৳${c.getLong(1)} • ${c.getString(3)}")
        c.close();return a
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var db: DBHelper
    private lateinit var body: LinearLayout
    private var lang="বাংলা ও English"
    private fun date()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    private fun money(v:Long)="৳"+String.format(Locale.US,"%,d",v)
    private fun label(bn:String,en:String)=if(lang=="English") en else if(lang=="বাংলা") bn else "$bn / $en"
    private fun text(s:String,size:Float=16f,bold:Boolean=false):TextView {
        return TextView(this).apply { text=s;textSize=size;setTextColor(Color.rgb(35,48,42)); if(bold)setTypeface(null,Typeface.BOLD); setPadding(8,9,8,9) }
    }
    private fun button(s:String, action:()->Unit):Button=Button(this).apply { text=s; setOnClickListener{action()} }
    private fun edit(hint:String):EditText=EditText(this).apply { this.hint=hint; singleLine=true; setPadding(12,8,12,8) }
    private fun add(v:View) { body.addView(v,LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT)) }
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState);db=DBHelper(this); authenticate() }
    private fun authenticate() {
        val bm=BiometricManager.from(this)
        val can=bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
        if(can!=BiometricManager.BIOMETRIC_SUCCESS) { showApp(); return }
        val prompt=BiometricPrompt(this,ContextCompat.getMainExecutor(this),object:BiometricPrompt.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){showApp()}
            override fun onAuthenticationError(errorCode:Int,errString:CharSequence){ if(errorCode==BiometricPrompt.ERROR_USER_CANCELED || errorCode==BiometricPrompt.ERROR_NEGATIVE_BUTTON) finish() }
        })
        val info=BiometricPrompt.PromptInfo.Builder().setTitle("Agent Manager BD")
            .setSubtitle("Fingerprint / device screen lock দিয়ে প্রবেশ করুন")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL).build()
        prompt.authenticate(info)
    }
    private fun showApp() {
        body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(16,12,16,24);setBackgroundColor(Color.rgb(247,250,248)) }
        val scroll=ScrollView(this);scroll.addView(body);setContentView(scroll); home()
    }
    private fun header() { add(text("Agent Manager BD",24f,true)); add(text("ব্যক্তিগত এজেন্ট হিসাব • Personal agent ledger",12f)) }
    private fun nav() {
        val row=LinearLayout(this)
        listOf("হোম","লেনদেন","বাকি","রিপোর্ট","সেটিংস").forEach { s ->
            row.addView(Button(this).apply { text=s;textSize=11f;setOnClickListener{when(s){"হোম"->home();"লেনদেন"->transactionForm();"বাকি"->dueForm();"রিপোর্ট"->report();"সেটিংস"->settings()}} },
                LinearLayout.LayoutParams(0,-2,1f))
        };add(row)
    }
    private fun totals(service:String):Long {
        val key=when(service){"বিকাশ"->"bkash";"নগদ"->"nagad";else->"rocket"}
        val base=db.setting(key)
        return base+db.txs().filter{it.service==service}.sumOf { if(it.type=="ক্যাশ ইন") -it.amount else it.amount }
    }
    private fun cashTotal()=db.setting("cash")+db.txs().sumOf{if(it.type=="ক্যাশ ইন")it.amount else -it.amount}
    private fun home() {
        body.removeAllViews();header();nav()
        add(text("ড্যাশবোর্ড / Dashboard",20f,true))
        add(text("হাতে ক্যাশ: ${money(cashTotal())}",18f,true))
        add(text("বিকাশ: ${money(totals("বিকাশ"))}    নগদ: ${money(totals("নগদ"))}"))
        add(text("রকেট: ${money(totals("রকেট"))}"))
        add(text("মোট কমিশন: ${money(db.txs().sumOf{it.commission})}"))
        add(text("কাস্টমারের বকেয়া: ${money(db.dueTotal())}"))
        add(text("সাম্প্রতিক লেনদেন",18f,true))
        db.txs().take(12).forEach { add(text("${it.date} • ${it.service} • ${it.type} • ${money(it.amount)} • কমিশন ${money(it.commission)}")) }
        if(db.txs().isEmpty()) add(text("এখনো কোনো লেনদেন যোগ করা হয়নি।"))
    }
    private fun transactionForm() {
        body.removeAllViews();header();nav();add(text("নতুন লেনদেন / New transaction",20f,true))
        val service=Spinner(this);service.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("বিকাশ","নগদ","রকেট"));add(text("সার্ভিস"));add(service)
        val type=Spinner(this);type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("ক্যাশ ইন","ক্যাশ আউট"));add(text("ধরন"));add(type)
        val amount=edit("টাকার পরিমাণ");add(amount);val commission=edit("কমিশন");add(commission);val customer=edit("কাস্টমারের নাম / রেফারেন্স (ঐচ্ছিক)");add(customer)
        add(button("লেনদেন সংরক্ষণ করুন / Save") {
            val a=amount.text.toString().toLongOrNull();val c=commission.text.toString().toLongOrNull()?:0
            if(a==null||a<=0||c<0) {Toast.makeText(this,"সঠিক টাকার পরিমাণ দিন",Toast.LENGTH_SHORT).show();return@button}
            db.addTx(service.selectedItem.toString(),type.selectedItem.toString(),a,c,customer.text.toString(),date())
            Toast.makeText(this,"লেনদেন সংরক্ষিত",Toast.LENGTH_SHORT).show();home()
        })
    }
    private fun dueForm() {
        body.removeAllViews();header();nav();add(text("কাস্টমারের বাকি / Customer dues",20f,true))
        add(text("মোট বকেয়া: ${money(db.dueTotal())}",18f,true))
        val name=edit("কাস্টমারের নাম");add(name);val amount=edit("টাকার পরিমাণ");add(amount)
        val kind=Spinner(this);kind.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("বাকি দেওয়া","বাকি আদায়"));add(kind)
        add(button("সংরক্ষণ করুন / Save") {
            val a=amount.text.toString().toLongOrNull()
            if(name.text.isBlank()||a==null||a<=0){Toast.makeText(this,"নাম ও সঠিক পরিমাণ দিন",Toast.LENGTH_SHORT).show();return@button}
            db.addDue(name.text.toString(),a,kind.selectedItem.toString(),date());dueForm()
        })
        db.dueRows().forEach{add(text(it))}
    }
    private fun report() {
        body.removeAllViews();header();nav();add(text("রিপোর্ট / Reports",20f,true))
        val all=db.txs();val today=all.filter{it.date==date()};val month=all.filter{it.date.startsWith(date().substring(0,7))}
        add(text("আজকের লেনদেন: ${today.size} • পরিমাণ ${money(today.sumOf{it.amount})}"))
        add(text("আজকের কমিশন: ${money(today.sumOf{it.commission})}"))
        add(text("এই মাসের লেনদেন: ${month.size} • পরিমাণ ${money(month.sumOf{it.amount})}"))
        add(text("এই মাসের কমিশন: ${money(month.sumOf{it.commission})}"))
        add(button("PDF রিপোর্ট তৈরি / Export PDF"){ exportPdf() })
        add(text("নোট: কমিশন মোট আয়; অন্যান্য খরচ বাদ না দিলে এটি নিট লাভ নয়।"))
    }
    private fun exportPdf() {
        val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create())
        val p=Paint().apply{color=Color.BLACK;textSize=16f}
        val lines=listOf("Agent Manager BD - Report","Date: ${date()}","Cash: ${money(cashTotal())}",
            "bKash: ${money(totals("বিকাশ"))}","Nagad: ${money(totals("নগদ"))}","Rocket: ${money(totals("রকেট"))}",
            "Total commission: ${money(db.txs().sumOf{it.commission})}","Customer dues: ${money(db.dueTotal())}","",
            "Transactions:") + db.txs().take(35).map{"${it.date} ${it.service} ${it.type} ${money(it.amount)} commission ${money(it.commission)}"}
        lines.forEachIndexed{i,line->page.canvas.drawText(line,40f,55f+i*20f,p)}
        doc.finishPage(page)
        val file=java.io.File(getExternalFilesDir(null),"AgentManagerBD-${date()}.pdf")
        try {file.outputStream().use{doc.writeTo(it)};Toast.makeText(this,"PDF saved: ${file.name}",Toast.LENGTH_LONG).show()
            val uri=androidx.core.content.FileProvider.getUriForFile(this,packageName+".provider",file)
            val intent=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
            startActivity(Intent.createChooser(intent,"PDF share / print"))
        } catch(e:Exception){Toast.makeText(this,"PDF তৈরি করা যায়নি: ${e.message}",Toast.LENGTH_LONG).show()}
        finally{doc.close()}
    }
    private fun settings() {
        body.removeAllViews();header();nav();add(text("প্রাথমিক ব্যালেন্স / Opening balances",20f,true))
        val fields=listOf("cash" to "হাতে ক্যাশ","bkash" to "বিকাশ","nagad" to "নগদ","rocket" to "রকেট")
        fields.forEach{(key,title)->val e=edit("$title: ${db.setting(key)}");e.setText(db.setting(key).toString());add(text(title));add(e)
            add(button("$title ব্যালেন্স সংরক্ষণ"){val v=e.text.toString().toLongOrNull();if(v==null||v<0)Toast.makeText(this,"সঠিক ব্যালেন্স দিন",Toast.LENGTH_SHORT).show() else {db.set(key,v.toString());Toast.makeText(this,"সংরক্ষিত",Toast.LENGTH_SHORT).show();settings()}})}
        add(text("অ্যাপটি অফলাইনে লোকাল ডেটাবেজে হিসাব রাখে। নিয়মিত ফোনের ব্যাকআপ রাখুন।"))
    }
}
